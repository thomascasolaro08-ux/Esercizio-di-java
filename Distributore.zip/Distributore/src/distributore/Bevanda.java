package distributore;

public class Bevanda {

    private String descrizione;
    private double prezzo;
    private boolean disponibile;
    private int indice;

    public Bevanda(String descrizione, double prezzo, boolean disponibile, int indice) {
        this.descrizione = descrizione;
        this.prezzo = prezzo;
        this.disponibile = disponibile;
        this.indice=indice;
    }

    public Bevanda() {
        this.descrizione = " ";
        this.prezzo = 0.0;
        this.disponibile = true;
                this.indice=0;
    }

    public Bevanda(Bevanda x) {
        this.descrizione = x.descrizione;
        this.prezzo = x.prezzo;
        this.disponibile = x.disponibile;
                this.indice=x.indice;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public double getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(double prezzo) {
        this.prezzo = prezzo;
    }

    public boolean isDisponibile() {
        return disponibile;
    }

    public void setDisponibile(boolean disponibile) {
        this.disponibile = disponibile;
    }

    public int getIndice() {
        return indice;
    }

    public void setIndice(int indice) {
        this.indice = indice;
    }
    

    boolean VerificaDisponibilita(boolean disponibile) {
        if (disponibile != true) {
            System.out.println("Bibita non disponibile");
        } else if (disponibile == true) {
            System.out.println("Bibita disponibile");
            return false;
        }
          return false;
    }

    @Override
    public String toString() {
        return "Bevanda{" + "descrizione=" + descrizione + ", prezzo=" + prezzo + ", disponibile=" + disponibile + ", indice=" + indice + '}';
    }
    
    

}
