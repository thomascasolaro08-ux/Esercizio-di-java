package distributore;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Distributore {

    public static String readln() {
        try {
            BufferedReader input
                    = new BufferedReader(new InputStreamReader(System.in));

            return input.readLine();
        } catch (IOException e) {
            System.out.println("Errore input da tastiera");

            System.out.println("Errore: " + e);

            return "";
        }
    }

    public static void main(String[] args) {
        ArrayList<Bevanda> bevande = new ArrayList<Bevanda>();
        int scelta;
        int indice = 0;
        do {
            System.out.println("1 Scegli tre bibite da mette;\n"
                    + "2 Stampa delle bibite presenti\n"
                    + "3 Trova una bibita tramite L'indice\n"
                    + "4 Controllo se la bevanda e' disponibile\n"
                    + "5 Esci");
            scelta = Integer.parseInt(readln());
            switch (scelta) {

                case 1:
                    System.out.println("Scegli tre bibite:"
                            + "Coca Cola\n"
                            + "Pespi\n"
                            + "Fanta\n"
                            + "Sprite\n"
                            + "Monster\n"
                            + "RedBull\n"
                            + "Crodino\n");
                    for (int i = 0; i < 3; i++) {
                        System.out.println("metti il nome della bevanda");
                        String descrizione = readln();

                        System.out.println("Inserisci il prezzo");
                        double prezzo = Double.parseDouble(readln());

                        System.out.println("inserisci se e' disponibile (y/n)");
                        String disp = readln();
                        boolean disponibilita = true;
                        if (disp.equals("y")) {
                            disponibilita = true;
                        } else if (disp.equals("n")) {
                            disponibilita = false;
                        }
                        bevande.add(new Bevanda(descrizione, prezzo, disponibilita, indice));
                        indice++;
                    }
                    break;

                case 2:
                    for (Bevanda x : bevande) {
                        System.out.println("\t" + " : " + x);
                    }

                    break;

                case 3:
                    System.out.println("metti l'indice della bevanda che cerchi");
                    int cerc = Integer.parseInt(readln());
                    for (Bevanda x : bevande) {
                        if (x.getIndice() == cerc) {
                            System.out.println("elemento trovato :");
                            System.out.println("\t" + " : " + x);
                        }
                    }

                    break;

                case 4:
                    System.out.println("metti la bevanda per vedere se e' disponibile");
                    String bev = readln();
                    for (Bevanda x : bevande) {
                        if (bev.equals(x.getDescrizione())) {
                            System.out.println(x.VerificaDisponibilita(x.isDisponibile()));
                        }
                    }

                    break;

            }
        } while (scelta != 5);

    }

}
